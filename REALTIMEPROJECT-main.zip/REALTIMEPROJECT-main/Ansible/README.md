## Usage:
* ansible-playbook -i hosts deploy.yml